/*
 * pycomm_qc.c
 *
 *  Created on: Jul 25, 2021
 *      Author: afaroo01
 */


#include "pycomm_qc.h"

coords get_bbox_coords(uint8_t *Rx)
{
	coords XY;
	XY.x_min = Rx[1]*256 + Rx[0];
	XY.y_min = Rx[3]*256 + Rx[2];
	XY.x_max = Rx[5]*256 + Rx[4];
	XY.y_max = Rx[7]*256 + Rx[6];
	return XY;
}
