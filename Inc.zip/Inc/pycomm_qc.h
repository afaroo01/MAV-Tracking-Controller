/*
 * pycomm_qc.h
 *
 *  Created on: Jul 25, 2021
 *      Author: afaroo01
 */

#ifndef INC_PYCOMM_QC_H_
#define INC_PYCOMM_QC_H_

#include <stdint.h>

typedef struct{
	unsigned int x_min;
	unsigned int x_max;
	unsigned int y_min;
	unsigned int y_max;
} coords;

coords get_bbox_coords(uint8_t *Rx);

#endif /* INC_PYCOMM_QC_H_ */
